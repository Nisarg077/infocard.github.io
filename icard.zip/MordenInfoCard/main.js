$('#expand-button').click(function() {
  $('.profile-card').toggleClass('expand');
})